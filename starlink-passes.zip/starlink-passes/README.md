# Starlink Ylilentolaskuri

Laskee Starlink-satelliittien ylilennot annettuun sijaintiin ja näyttää ne web-käyttöliittymässä.

## Ominaisuudet

- Hakee TLE-ratatiedot Celestrakista (9000+ satelliittia)
- Laskee ylilennot annetun etäisyyden sisällä
- Web-käyttöliittymä GitHub Pagesissa
- Automaattinen päivitys 6 tunnin välein

## Käyttö

### Komentorivi

```bash
# Oletusarvot (Jyväskylä, 500km, 24h)
python3 starlink_pass_calculator.py

# Mukautetut arvot
python3 starlink_pass_calculator.py --lat 60.1699 --lon 24.9384  # Helsinki
python3 starlink_pass_calculator.py --max-distance 300 --hours 12

# JSON-tuloste web-käyttöliittymälle
python3 starlink_pass_calculator.py --json docs/passes.json
```

### Parametrit

| Parametri | Oletus | Kuvaus |
|-----------|--------|--------|
| `--lat` | 62.2426 | Leveyspiiri (Jyväskylä) |
| `--lon` | 25.7473 | Pituuspiiri |
| `--max-distance` | 500 | Maksimietäisyys (km) |
| `--hours` | 24 | Laskenta-aika eteenpäin |
| `--top` | 10 | Näytettävien määrä |
| `--tz` | 2 | Aikavyöhyke (UTC+2) |
| `--json` | - | Tallenna JSON-tiedostoon |

## GitHub Pages

1. Luo uusi julkinen repositorio
2. Pura tiedostot ja puske repoon
3. Mene **Settings** → **Pages** → **Source**: GitHub Actions
4. Workflow päivittää datan automaattisesti

## Tiedostot

```
├── starlink_pass_calculator.py  # Pääskripti
├── docs/
│   ├── index.html               # Web-käyttöliittymä
│   └── passes.json              # Lasketut ylilennot
├── .github/
│   └── workflows/
│       └── update-passes.yml    # Automaattinen päivitys
└── .gitignore
```

## Lisenssi

MIT
